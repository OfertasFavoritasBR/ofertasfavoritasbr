# Ofertas Favoritas BR

Este é o site oficial da **Ofertas Favoritas BR**, representante autorizado do **AssisChat** — solução inteligente para automação de atendimento via WhatsApp.

## 💡 Sobre

Através deste site, você pode conhecer os principais benefícios do AssisChat, como:

- Atendimento automático 24h
- Agendamento de clientes
- Leitura de comprovantes PIX
- Disparos promocionais

## 🌐 Acesse o site

👉 [Clique aqui para visitar](https://seunome.github.io/ofertasfavoritasbr)  
(Atualize o link após publicação)

## 📲 Contato

Fale conosco via WhatsApp: [wa.me/5541997166779](https://wa.me/5541997166779)

---

Desenvolvido por Ofertas Favoritas BR | Representante AssisChat